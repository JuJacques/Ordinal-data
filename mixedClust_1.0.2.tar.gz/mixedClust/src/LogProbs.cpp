#include "LogProbs.h"


LogProbs::LogProbs(double row, double col)
{
	this->_row = row;
	this->_col = col;
}
LogProbs::LogProbs()
{
}


LogProbs::~LogProbs()
{
}
